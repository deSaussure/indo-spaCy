# coding: utf8
from __future__ import unicode_literals


"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.fa.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "این یک جمله نمونه می باشد.",
    "قرار ما، امروز ساعت ۲:۳۰ بعدازظهر هست!",
    "دیروز علی به من ۲۰۰۰.۱﷼ پول نقد داد.",
    "چطور می‌توان از تهران به کاشان رفت؟",
    "حدود ۸۰٪ هوا از نیتروژن تشکیل شده است.",
]
